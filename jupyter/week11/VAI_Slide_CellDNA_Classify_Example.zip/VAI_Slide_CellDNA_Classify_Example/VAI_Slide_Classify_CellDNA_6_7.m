%% VAI_Slide_Classify_CellDNA.m

function VAI_Slide_Classify_CellDNA

dbstop if error

%% read / prepare data X1, X2
data1 = readmatrix('CellDNA_data1.csv');
data2 = readmatrix('CellDNA_data2.csv');

data1 = [data1, data2];
data2 = data1;

[rows, dim1] = size(data1);
[rows, dim2] = size(data2);

Z_data1 = zscore(data1);      % 1217*6
Z_data2 = zscore(data2);      % 1217*7

%% read / prepare Y
raw_Y = readmatrix('CellDNA_targets.csv');
raw_Y(find(raw_Y ~= 0)) = 1;
Y = categorical(raw_Y);

classes = numel(unique(raw_Y));

%% put data into 3 stores to simulate 3 input streams to NN
% Format of datastore to NN must be vars*records, and iterate through dim 2 of "records"
dsX1 = arrayDatastore(Z_data1', "IterationDimension", 2);     % , "IterationDimension", 2
dsX2 = arrayDatastore(Z_data2', "IterationDimension", 2);     % , "IterationDimension", 2

dsY = arrayDatastore(Y);

dsAll = combine(dsX1, dsX2, dsY);

%% split, https://www.mathworks.com/help/signal/ug/data-organization.html
cnt = countlabels(dsAll, UnderlyingDatastoreIndex = 3)

preview(dsAll)

%%
layers1 = [
    featureInputLayer(dim1)
    fullyConnectedLayer(10)
    reluLayer
    fullyConnectedLayer(7)
    reluLayer
    fullyConnectedLayer(4)
    reluLayer
    fullyConnectedLayer(2)
    softmaxLayer];

net1 = dlnetwork(layers1);

layers2 = [
    featureInputLayer(dim2)
    fullyConnectedLayer(10)
    reluLayer
    fullyConnectedLayer(8)
    reluLayer
    fullyConnectedLayer(6)
    reluLayer
    fullyConnectedLayer(4)
    reluLayer
    fullyConnectedLayer(2)
    softmaxLayer];

net2 = dlnetwork(layers2);

%%
numEpochs = 100;       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initialLearnRate = 0.01;
decay = 0;      % 0.01;
momentum = 0;   % 0.9;
 
miniBatchSize = 50;      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numObservationsTrain = numel(raw_Y);
numIterationsPerEpoch = floor(numObservationsTrain / miniBatchSize);
numIterations = numEpochs * numIterationsPerEpoch;

%% setup batches
mbq = minibatchqueue(dsAll,...
    MiniBatchSize=miniBatchSize, ...
    MiniBatchFcn=@preprocessMiniBatch, ...
    MiniBatchFormat=["CB" "CB" "CB"] ...     %%%%%% *******************************
);  % https://www.mathworks.com/help/deeplearning/ref/dlarray.html

[X1, X2, T] = next(mbq);

mbqTest = minibatchqueue(dsAll,...
    MiniBatchSize=miniBatchSize, ...
    MiniBatchFcn=@preprocessMiniBatch, ...
    MiniBatchFormat=["CB" "CB" "CB"] ...     %%%%%% *******************************
);  % https://www.mathworks.com/help/deeplearning/ref/dlarray.html

%%
monitor = trainingProgressMonitor( ...
    Metrics="Loss", ...
    Info=["Epoch" "LearnRate"], ...
    XLabel="Iteration");

%%
epoch = 0;
iteration = 0;
velocity1 = [];  % parameter for SGDM solver 
velocity2 = [];  % parameter for SGDM solver 

% Loop over epochs.
while epoch < numEpochs && ~monitor.Stop
    epoch = epoch + 1;

    % Shuffle data.
    shuffle(mbq);
    
    % Loop over mini-batches.
    while hasdata(mbq) && ~monitor.Stop

        iteration = iteration + 1;
        
        % Read mini-batch of data.
        [X1, X2, T] = next(mbq);
        
        % Evaluate the model gradients, state, and loss using dlfeval and the
        % modelLoss function and update the network state.
        [TotalLoss, gradients1, state1, gradients2, state2] = ...
                    dlfeval(@lossXEntropy_2, net1, net2, X1, X2, T);
        net1.State = state1;
        net2.State = state2;
        
        % Determine learning rate for time-based decay learning rate schedule.
        learnRate = initialLearnRate/(1 + decay*iteration);
        
        % Update the network parameters using the SGDM optimizer.
        [net1, velocity1] = sgdmupdate(net1, gradients1, velocity1, learnRate, momentum);
        [net2, velocity2] = sgdmupdate(net2, gradients2, velocity2, learnRate, momentum);
        
        % Update the training progress monitor.
        recordMetrics(monitor, iteration,Loss = TotalLoss);
        updateInfo(monitor,Epoch=epoch,LearnRate=learnRate);

        progresstmp = 100 * iteration/numIterations;
        if progresstmp > 100,   progresstmp = 100;      end
        monitor.Progress = progresstmp;
    end
end


%%
reset(mbq)
classes = 2;
[yhat_OverAll1, yhat_OverAll2] = TwoModelPredictions(net1, net2, mbq, classes);


accuracy1 = mean(raw_Y == yhat_OverAll1)
CFM1 = confusionmat(raw_Y,  yhat_OverAll1)

accuracy2 = mean(raw_Y == yhat_OverAll2)
CFM2 = confusionmat(raw_Y,  yhat_OverAll2)

return


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% T = Target, from (0, 1) becomes (1, 2) automatically
function [loss, gradients1, state1, gradients2, state2] = lossXEntropy_2(net1, net2, X1, X2, T)

% one-hot for the following XEntropy computing
classes = 2;
tt = onehotencode(T, 1, 'ClassNames', 1:classes);   

% Forward data through network.
[yhat1, state1] = forward(net1, X1);
[yhat2, state2] = forward(net2, X2);

% Calculate cross-entropy loss.
loss1 = crossentropy(yhat1, tt);
loss2 = crossentropy(yhat2, tt);

loss = (loss1 + loss2) / 2;

% Calculate gradients of loss with respect to learnable parameters.
gradients1 = dlgradient(loss, net1.Learnables);
gradients2 = dlgradient(loss, net2.Learnables);

return


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
function [yhat_OverAll1, yhat_OverAll2] = TwoModelPredictions(net1, net2, mbq, classes)

yhat_OverAll1 = [];
yhat_OverAll2 = [];

% Loop over mini-batches.
while hasdata(mbq)
    [X1, X2, T] = next(mbq);

    % Make prediction.
    Scores1 = predict(net1, X1);
    [maxScores yhat_tmp1] = max(Scores1);

    % transpose output or not depends on your original input shape
    %yhat1 = extractdata(gather(yhat_tmp1)).'  - 1;
    yhat1 = extractdata(gather(yhat_tmp1))  - 1;

    %yhat1 = categorical(yhat1');

    % Decode labels  **IF** needed
    %yhat1 = onehotencode(yhat1, 2);

    % append to output
    yhat_OverAll1 = [yhat_OverAll1; yhat1'];


    % Make prediction.
    Scores2 = predict(net2, X2);
    [maxScores yhat_tmp2] = max(Scores2);

    % transpose output or not depends on your original input shape
    %yhat2 = extractdata(gather(yhat_tmp2)).'  - 1;
    yhat2 = extractdata(gather(yhat_tmp2))  - 1;

    %yhat2 = categorical(yhat2');

    % Decode labels  **IF** needed
    %yhat2 = onehotencode(yhat2, 2);

    % append to output
    yhat_OverAll2 = [yhat_OverAll2; yhat2'];
end

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% dataT = Target, of input Y = (0, 1)
function [X1, X2, T] = preprocessMiniBatch(dataX1, dataX2, dataT)

% Preprocess predictors.
X1 = cat(2, dataX1{1 : end});     % if input is regular feature array
X2 = cat(2, dataX2{1 : end});     % if input is regular feature array
%X = cat(4, dataX{1:end});       % if input is image  

% Extract label data from cell and concatenate.
T = cat(2, dataT{1 : end});

return
