%% preprocessMiniBatch_Digits.m

function [X1, X2, T] = preprocessMiniBatch_Digits(dataX1, dataX2, dataT)

% Preprocess predictors.
if ndims(dataX1) == 4
    X1 = cat(4, dataX1{:});     % input = images
else
    X1 = cat(2, dataX1{1 : end});     % input = images
end

X2 = cat(2, dataX2{1 : end});     % if input is regular feature array
%X = cat(4, dataX{1:end});       % if input is image  

% Extract label data from cell and concatenate.
T = cat(2, dataT{1 : end});

return
