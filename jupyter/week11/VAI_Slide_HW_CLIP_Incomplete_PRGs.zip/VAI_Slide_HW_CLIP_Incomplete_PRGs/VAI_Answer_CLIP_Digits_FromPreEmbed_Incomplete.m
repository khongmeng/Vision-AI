
function VAI_Answer_CLIP_Digits_FromPreEmbed_Incomplete(CLIP_MatFName)
dbstop if error

if nargin < 1,      TrainFlag = 1;      CLIP_MatFName = '';           
else                TrainFlag = 0;
end

addpath("Util_Functions\", "WordEmbedding\")

PairFlag = 1;

MyEpochs = 1200;

Z_VecDim = 300;

temperature = 0.7;      % 0.8   1.3

%% read / prepare data X1, X2
load('VAI_HW_CLIP_Image_Vecs.mat', 'Img_Vecs', 'imds');     
Ys = double(imds.Labels) - 1;
load('VAI_HW_CLIP_Text_Vecs.mat', 'Text_Vecs');    
figure, 
subplot(1,2,1), imagesc(squareform(pdist(Img_Vecs))); colorbar; 
subplot(1,2,2), imagesc(squareform(pdist(Text_Vecs))); colorbar;

%%
Text_Vecs_InputOrdered = Text_Vecs;
if PairFlag == 0
    Perm_Idx = randperm(size(Text_Vecs, 1));
    TotSwaps = 30;      % 10%
    Perm_Idx = Perm_Idx(1:TotSwaps);
    for pp = 1 : TotSwaps/2
        idx1 = Perm_Idx(pp);    idx2 = Perm_Idx(pp + TotSwaps/2);
        tmp = Text_Vecs(idx2, :);
        Text_Vecs(idx2, :) = Text_Vecs(idx1, :);
        Text_Vecs(idx1, :) = tmp;
    end
end

%% build data store for training
dsImage = arrayDatastore(Img_Vecs', "IterationDimension", 2);

dsY = arrayDatastore(Ys);

dsText = arrayDatastore(Text_Vecs', "IterationDimension", 2);


%dsAll = combine(dsImage, dsText);
dsAll = combine(dsImage, dsText, dsY);

%% split, https://www.mathworks.com/help/signal/ug/data-organization.html
cnt = countlabels(dsAll, UnderlyingDatastoreIndex = 3)
idxs = splitlabels(dsAll, [0.8 0.2], "randomized", UnderlyingDatastoreIndex = 3);
TrainIdx = idxs{1};
TestIdx = idxs{2};
trainDs = subset(dsAll, TrainIdx);
testDs = subset(dsAll, TestIdx);

preview(dsAll)

%%
% stream 1
ImgLayers = [
    featureInputLayer(size(Img_Vecs, 2),'Name','input 1')
    fullyConnectedLayer(1000, 'Name', 'S1_FC_1')
    reluLayer()
    fullyConnectedLayer(750, 'Name', 'S1_FC_1')
    reluLayer()
    fullyConnectedLayer(500, 'Name', 'S1_FC_1')
    reluLayer()
    fullyConnectedLayer(Z_VecDim, 'Name', 'S1_FC_1')
    reluLayer()
];
net1 = dlnetwork(ImgLayers);


TextLayers = [
    featureInputLayer(size(Text_Vecs, 2),'Name','input 1')
    fullyConnectedLayer(2200, 'Name', 'S1_FC_2')
    reluLayer()
    fullyConnectedLayer(1600, 'Name', 'S1_FC_2')
    reluLayer()
    fullyConnectedLayer(900, 'Name', 'S1_FC_2')
    reluLayer()
    fullyConnectedLayer(500, 'Name', 'S1_FC_2')
    reluLayer()
    fullyConnectedLayer(Z_VecDim, 'Name', 'S1_FC_2')
    reluLayer()
];
net2 = dlnetwork(TextLayers);

%%
numEpochs = MyEpochs;       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initialLearnRate = 0.01;
decay = 0.000001;      % 0.01;
momentum = 0.;   % 0.9;

miniBatchSize = 20;      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


numObservationsTrain = numel(TrainIdx);
numIterationsPerEpoch = floor(numObservationsTrain / miniBatchSize);
numIterations = numEpochs * numIterationsPerEpoch;

%% setup batches
mbq = minibatchqueue(trainDs,...
    MiniBatchSize=miniBatchSize, ...
    MiniBatchFcn=@VAI_Answer_CLIP_Digits_MiniBatch, ...
    MiniBatchFormat=["CB" "CB" "CB"], ...     %%%%%% *******************************
    PartialMiniBatch = "return" ...
);  % https://www.mathworks.com/help/deeplearning/ref/dlarray.html
%   PartialMiniBatch="discard");        % or "return" all

[X1, X2, T] = next(mbq);

%%
mbqTest = minibatchqueue(testDs,...
    MiniBatchSize=miniBatchSize, ...
    MiniBatchFcn=@VAI_Answer_CLIP_Digits_MiniBatch, ...
    MiniBatchFormat=["CB" "CB" "CB"], ...     %%%%%% *******************************
    PartialMiniBatch = "return" ...
);  % https://www.mathworks.com/help/deeplearning/ref/dlarray.html

%%%%%%%%%%%%%%%
if TrainFlag == 1

%%
monitor = trainingProgressMonitor( ...
    Metrics="Loss", ...
    Info=["Epoch" "LearnRate"], ...
    XLabel="Iteration");

%%
epoch = 0;
iteration = 0;
velocity1 = [];  % parameter for SGDM solver 
velocity2 = [];  % parameter for SGDM solver 

% Loop over epochs.
while epoch < numEpochs && ~monitor.Stop
    epoch = epoch + 1;

    % Shuffle data.
    shuffle(mbq);
    
    % Loop over mini-batches.
    while hasdata(mbq) && ~monitor.Stop

        iteration = iteration + 1;
        
        % Read mini-batch of data.
        [X1, X2, T] = next(mbq);
        
        % Evaluate the model gradients, state, and loss using dlfeval and the
        % modelLoss_Version_2 function and update the network state.
        [TotalLoss, gradients1, state1, gradients2, state2] = ...
                    dlfeval(@VAI_Answer_CLIP_Digits_modelLoss, net1, net2, X1, X2, temperature);
        net1.State = state1;
        net2.State = state2;
        
        % Determine learning rate for time-based decay learning rate schedule.
        learnRate = initialLearnRate/(1 + decay*iteration);
        
        % Update the network parameters using the SGDM optimizer.
        [net1, velocity1] = sgdmupdate(net1, gradients1, velocity1, learnRate, momentum);
        [net2, velocity2] = sgdmupdate(net2, gradients2, velocity2, learnRate, momentum);
        
        % Update the training progress monitor.
        recordMetrics(monitor, iteration,Loss = TotalLoss);
        updateInfo(monitor,Epoch=epoch,LearnRate=learnRate);
        monitor.Progress = 100 * iteration/numIterations;
    end
end
NetImage_1 = net1;
NetText_2 = net2;

if PairFlag == 0    %%%%%%%%%%%%%%%%%%%%%%%%%% 
    % if training based on unpaired img-text, then "Text_InputVectors" has
    % been randomly shuffled. Hence, put the order back after training for
    % analysis / visual purpose.
    Text_Vecs = Text_Vecs_InputOrdered;
end


elseif TrainFlag == 0   %% No training, just load a pre-trained CLIP model
    load(CLIP_MatFName)
end

%%
reset(mbq)
[ExZ1_Array, ExZ2_Array, Target_Array,  Sim_Array] = ...
    VAI_Answer_CLIP_Digits_modelPredictions(NetImage_1, NetText_2, mbq);

a=cosineSimilarity(ExZ1_Array, ExZ2_Array);

figure, subplot(2,2,1), imagesc(a); colorbar

zz1=tsne(ExZ1_Array);
zz2=tsne(ExZ2_Array);
%subplot(2,2,2), plot(Target_Array)
subplot(2,2,3), gscatter(zz1(:,1), zz1(:,2), Target_Array)
subplot(2,2,4), gscatter(zz2(:,1), zz2(:,2), Target_Array)

%%
reset(mbqTest)
[ExZ1_Array_test, ExZ2_Array_test, Target_Array_test,  Sim_Array_test] = ...
                        VAI_Answer_CLIP_Digits_modelPredictions(NetImage_1, NetText_2, mbqTest);

b=cosineSimilarity(ExZ1_Array_test, ExZ2_Array_test);
figure, subplot(2,2,1), imagesc(b); colorbar

zz1_test = tsne(ExZ1_Array_test);
zz2_test = tsne(ExZ2_Array_test);
subplot(2,2,2), plot(Target_Array_test)
subplot(2,2,3), gscatter(zz1_test(:,1), zz1_test(:,2), Target_Array_test)
subplot(2,2,4), gscatter(zz2_test(:,1), zz2_test(:,2), Target_Array_test)

%%
if TrainFlag == 1
    save('VAI_Answer_CLIP_Digits_PreEmbed_Paired.mat', 'NetImage_1', 'NetText_2', 'mbq', 'mbqTest', ...
                'PairFlag', 'dsImage', 'dsText', 'dsY', 'dsAll', ...
                'idxs', 'TrainIdx', 'TestIdx', 'trainDs', 'testDs', ...
                'Z_VecDim', 'temperature', ...
                'MyEpochs', 'initialLearnRate', 'decay', 'momentum', 'miniBatchSize')
end

return
