function [ExZ1_Array, ExZ2_Array, Target_Array,  Sim_Array] = ...
    VAI_Answer_CLIP_Digits_modelPredictions(net1, net2, mbq)

Sim_Array = [];
ExZ1_Array = [];
ExZ2_Array = [];
Target_Array = [];

% Loop over mini-batches.
while hasdata(mbq)
    [X1, X2, T] = next(mbq);

    [Z1, state1] = forward(net1, X1);
    [Z2, state2] = forward(net2, X2);

    ExZ1 = extractdata(Z1)';
    ExZ2 = extractdata(Z2)';

    %%
    Target_Array = [Target_Array, T];
    ExZ1_Array = [ExZ1_Array; ExZ1];
    ExZ2_Array = [ExZ2_Array; ExZ2];
end

%%
Target_Array = gather(extractdata(Target_Array))';
ExZ1_Array = gather(ExZ1_Array);
ExZ2_Array = gather(ExZ2_Array);

%%
[TT, Tidx] = sort(Target_Array);
ExZ1_Array = ExZ1_Array(Tidx, :);
ExZ2_Array = ExZ2_Array(Tidx, :);
Target_Array = Target_Array(Tidx);

Sim_Array = PairwiseCosineSimilarity(ExZ1_Array', ExZ2_Array');

return


